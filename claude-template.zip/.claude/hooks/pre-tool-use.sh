#!/bin/bash
# Pre-tool-use safety hook
# Blocks dangerous bash commands before Claude runs them

# Read JSON from stdin
input=$(cat)

# Extract command from input (assumes Bash tool)
command=$(echo "$input" | grep -oE '"command"\s*:\s*"[^"]*"' | sed 's/.*"command"\s*:\s*"\([^"]*\)".*/\1/')

# Forbidden patterns — exit 2 to block, with message to stderr
forbidden=(
  "rm -rf /"
  "rm -rf ~"
  "rm -rf \\*"
  ":(){ :|:& };:"
  "DROP DATABASE"
  "DROP TABLE.*--"
  "git push.*--force"
  "git push.*-f "
  "kubectl delete.*--all"
  "chmod -R 777 /"
  "curl.*\\|.*sh"
  "curl.*\\|.*bash"
  "wget.*\\|.*sh"
  "> /dev/sda"
  "dd if=.*of=/dev"
)

for pattern in "${forbidden[@]}"; do
  if echo "$command" | grep -qE "$pattern"; then
    echo "🛑 BLOCKED by pre-tool-use hook" >&2
    echo "Command matched forbidden pattern: $pattern" >&2
    echo "Command: $command" >&2
    echo "" >&2
    echo "If you're sure you want to do this, run it manually outside Claude Code." >&2
    exit 2
  fi
done

# Warning patterns — log but allow
warning=(
  "rm -rf"
  "DROP TABLE"
  "TRUNCATE"
  "git reset --hard"
)

for pattern in "${warning[@]}"; do
  if echo "$command" | grep -qE "$pattern"; then
    echo "⚠️  WARNING: potentially destructive command" >&2
    echo "Command: $command" >&2
    break
  fi
done

# Exit 0 to allow
exit 0
