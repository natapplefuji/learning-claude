#!/bin/bash
# Before-commit quality hook
# Runs lint + test based on what changed
# Registered as "Stop" hook — runs when Claude finishes a task

set -e

# Detect what changed in current working tree
changed=$(git diff --name-only HEAD 2>/dev/null || echo "")
staged=$(git diff --cached --name-only 2>/dev/null || echo "")
all_changed="$changed
$staged"

# Skip if nothing changed
if [ -z "$all_changed" ] || [ "$all_changed" == "
" ]; then
  exit 0
fi

# Detect stack
has_backend=false
has_frontend=false

if echo "$all_changed" | grep -qE "(\.java$|pom\.xml|build\.gradle)"; then
  has_backend=true
fi

if echo "$all_changed" | grep -qE "(\.tsx?$|\.jsx?$|package\.json)"; then
  has_frontend=true
fi

# Backend checks
if [ "$has_backend" = true ] && [ -d "backend" ]; then
  echo "🔧 Running backend checks..."
  cd backend
  
  # Format
  if [ -f "pom.xml" ] && grep -q "spotless" pom.xml; then
    mvn spotless:apply -q || {
      echo "❌ Backend formatting failed" >&2
      exit 1
    }
  fi
  
  # Test (only if not in CI to avoid double-run)
  if [ -z "$CI" ]; then
    echo "🧪 Running backend tests..."
    mvn test -q -DfailIfNoTests=false || {
      echo "❌ Backend tests failed" >&2
      exit 1
    }
  fi
  
  cd ..
fi

# Frontend checks
if [ "$has_frontend" = true ] && [ -d "frontend" ]; then
  echo "🔧 Running frontend checks..."
  cd frontend
  
  # Lint
  if [ -f "package.json" ] && grep -q "\"lint\"" package.json; then
    npm run lint --silent || {
      echo "❌ Frontend lint failed" >&2
      exit 1
    }
  fi
  
  # Type check
  if [ -f "tsconfig.json" ]; then
    npx tsc --noEmit || {
      echo "❌ Frontend type check failed" >&2
      exit 1
    }
  fi
  
  # Test
  if [ -z "$CI" ] && grep -q "\"test\"" package.json; then
    echo "🧪 Running frontend tests..."
    npm test -- --run --silent || {
      echo "❌ Frontend tests failed" >&2
      exit 1
    }
  fi
  
  cd ..
fi

echo "✅ All checks passed"
exit 0
