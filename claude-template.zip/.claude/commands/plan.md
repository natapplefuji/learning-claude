---
description: Start a structured planning session for a feature or change
---

# /plan

Begin structured planning for a non-trivial change.

Switch to plan mode (read-only) and produce a plan covering:

1. **Goal** — What problem are we solving? (1-2 sentences)
2. **Scope** — What's in / out of scope
3. **Affected files** — Which files will change, which will be created
4. **Approach** — High-level strategy
5. **Steps** — Ordered implementation steps with rough sizing (XS/S/M/L)
6. **Risks** — What could go wrong, mitigation
7. **Test strategy** — What tests at which layer
8. **Rollback** — If this breaks production, how do we undo?

After presenting plan, ask user to:
- Approve as-is
- Adjust scope/approach
- Drill into specific step

Don't write code while in plan mode. Only switch out when user explicitly approves.
