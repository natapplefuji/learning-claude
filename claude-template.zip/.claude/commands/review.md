---
description: Review uncommitted changes against project conventions
---

# /review

Run a thorough self-review of pending changes before commit.

Steps:

1. Run `git status` to see what's changed
2. Run `git diff` to see the actual changes
3. Read all relevant CLAUDE.md files (root + sub-folders for changed files)
4. Dispatch the `code-reviewer` agent with the diff

The reviewer should output:
- Summary
- 🔴 BLOCK items (must fix)
- 🟡 CONCERN items (should consider)
- 🟢 PASS items (positive notes)
- Recommendation: APPROVE / REQUEST CHANGES / DRAFT

After review, ask user:
- Address BLOCK items now?
- Defer CONCERN items to follow-up?
- Or proceed to commit anyway?
