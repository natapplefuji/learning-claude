---
description: Guide through commit + push + PR flow with quality checks
---

# /ship

Walk through the ship-it process for current changes.

Steps:

1. **Pre-flight check** — run `git status` and `git diff --stat`
2. **Self-review** — dispatch `/review` (or skip if user just did)
3. **Commit**
   - Group related changes if multiple commits make sense
   - Use conventional commit format: `type(scope): description`
   - Reference issue if applicable: `feat(auth): add login (#42)`
4. **Push** — to current branch (create if not exists)
5. **PR** (if GitHub MCP available)
   - Title: same as commit (or summary if multiple commits)
   - Body should include:
     - What changed (1-3 bullets)
     - Why (link to issue or brief reason)
     - How to test (manual steps)
     - Screenshots if UI change
   - Self-leave 1-2 review comments on things to watch

Always confirm with user before:
- Force pushing
- Pushing to main directly
- Auto-merging

If pre-commit hook fails, stop and report — don't bypass with `--no-verify` unless user explicitly asks
