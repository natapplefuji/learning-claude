---
name: api-endpoint
description: Add a new REST API endpoint to the backend. Use when user asks to "add", "create", or "implement" an endpoint, route, or API.
---

# API Endpoint

ใช้ skill นี้เมื่อมีการขอเพิ่ม REST endpoint ใหม่

## When to use

Activate when user explicitly asks for:
- "Add endpoint X"
- "Implement POST /api/foo"
- "Create REST API for ..."
- "I need an endpoint that ..."

Do NOT activate for:
- Frontend API client work (use frontend-component or api-client skill)
- Internal service-to-service calls (different patterns)
- GraphQL resolvers (different paradigm)

## Required input

Before starting, confirm with user:

1. **HTTP method + path** — e.g. `POST /api/tasks`
2. **Request shape** — JSON structure or DTO fields
3. **Response shape** — success response (200/201) JSON
4. **Error cases** — which status codes and when (400, 401, 404, 409, etc.)
5. **Auth required?** — public, authenticated, or role-based
6. **Side effects?** — emit event, send notification, etc.

ถ้าข้อมูลขาด ถามก่อน — อย่าเดา

## Process

ทำตามลำดับนี้ — อย่าข้าม step:

### 1. Create DTOs

- Request DTO with validation annotations (`@NotBlank`, `@Email`, `@Min`, etc.)
- Response DTO (separate from entity — never expose entity directly)
- Error response uses existing common format

### 2. Update or create entity (if needed)

- ถ้าต้อง persist data ใหม่ — entity + repository
- Entity field types ต้องตรงกับ DB schema (verify ผ่าน MCP postgres ถ้ามี)

### 3. Service layer

- Method ใน service class ที่ทำ business logic
- ไม่ควรรู้จัก HTTP — รับ + คืนค่า object เท่านั้น
- Throw domain exceptions (custom) ไม่ใช่ HTTP exception

### 4. Controller method

- Add method ใน controller ที่ตรงกับ resource
- Use proper annotations: `@PostMapping`, `@GetMapping`, etc.
- `@Valid` บน request body
- Return `ResponseEntity` หรือ DTO ตรงๆ ตาม project convention

### 5. Exception handling

- ถ้ามี new domain exception — เพิ่มใน global `@ControllerAdvice`
- Map exception → HTTP status ที่ถูกต้อง

### 6. Tests

**Service layer test** — JUnit + Mockito:
- Happy path
- Each error case
- Edge: null input, empty list, boundary values

**Controller integration test** — MockMvc:
- 200/201 response shape ตรง
- Validation errors return 400 พร้อม error detail
- Auth: 401 ถ้าไม่ login (ถ้า protected)

### 7. Documentation

- Update OpenAPI annotations ถ้า project ใช้
- ถ้ามี `README.md` หรือ `API.md` — update

## Output checklist

หลังทำเสร็จ verify:

- [ ] ไฟล์ DTO สร้างแล้ว
- [ ] Service method มี
- [ ] Controller method ใช้งานได้
- [ ] Exception mapping ถูก
- [ ] Tests ผ่านทั้ง 2 layer
- [ ] `mvn compile` ผ่าน
- [ ] `mvn test` ผ่าน
- [ ] manual test ด้วย curl หรือ http client (1 happy path + 1 error path)

## Conventions ที่ต้อง respect

อ่าน `backend/CLAUDE.md` ก่อนเริ่ม — convention เฉพาะ project อาจ override default ที่นี่

Default ถ้าไม่มี CLAUDE.md backend:
- Package: `com.{company}.{feature}`
- Layer separation: Controller → Service → Repository (no skip)
- Tests: `should_X_when_Y` naming
- DTO suffix: `Request`, `Response`
- Exception suffix: `Exception` (custom domain) or use built-in
