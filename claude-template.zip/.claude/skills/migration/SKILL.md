---
name: migration
description: Create a database migration. Use when user asks to "add a table", "modify schema", "add a column", or "create migration".
---

# Database Migration

ใช้ skill นี้เมื่อต้องเปลี่ยน database schema

## When to use

Activate for:
- "Add a {table} table"
- "Add column X to table Y"
- "Migrate database to support ..."
- "Drop column / rename column"
- Index changes

Do NOT activate for:
- Querying data (just write SQL)
- Seeding test data (different concern)
- Schema design ก่อน implement (use plan mode first)

## Required input

1. **Change type** — create table, alter table, drop, index, etc.
2. **Affected tables** — which tables
3. **Backwards compatibility** — code นี้จะ deploy ทันทีไหม? data ที่มีอยู่ pose problem ไหม?

## Process

### 1. Check current schema

ถ้ามี Postgres MCP:
- Query existing schema ก่อน — `describe_table {target}`
- ตรวจว่าจริงตามที่ user คิด

ถ้าไม่มี MCP:
- หา migration files ก่อนหน้า — แล้วไล่ดู current state

### 2. Create migration file

ตาม convention ของ project:

**Flyway** (Spring Boot):
```
src/main/resources/db/migration/V{N}__{description}.sql
```

**Liquibase**:
```
src/main/resources/db/changelog/{N}-{description}.yaml
```

**Knex/Prisma/etc.**: ตาม project rule

### 3. Write the migration

**ทุก migration ต้องคิดเรื่องนี้**:

#### Add table
```sql
CREATE TABLE {name} (
  id UUID PRIMARY KEY,
  -- columns
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
  deleted_at TIMESTAMP NULL  -- ถ้าต้องการ soft delete
);

-- Foreign keys
ALTER TABLE {name} ADD CONSTRAINT fk_{name}_{ref}
  FOREIGN KEY ({ref}_id) REFERENCES {ref}(id);

-- Indexes (อย่าลืม!)
CREATE INDEX idx_{name}_{column} ON {name}({column});
```

#### Add column
```sql
ALTER TABLE {name}
  ADD COLUMN {column} {type} {NULL/NOT NULL DEFAULT ...};
```

⚠️ ถ้า NOT NULL — ต้องมี DEFAULT หรือ migrate ข้อมูลก่อน

#### Drop column / rename
- Multi-step: เพิ่มใหม่ → migrate data → ลบเก่า
- อย่า drop เลยถ้ามี data จริง

### 4. Verify

ถ้ามี Postgres MCP:
- Apply migration (run `mvn flyway:migrate` หรือ project equivalent)
- Query schema ด้วย MCP — ตรวจว่าผลลัพธ์ตรง

ถ้าไม่มี MCP:
- Apply locally
- รัน `\d {table}` ใน psql

### 5. Update code

หลัง migration:
- Entity/model class — update ให้ตรง
- Repository interfaces — เพิ่ม method ถ้าต้องการ
- Tests — fix ที่พังจาก schema change

## Checklist before commit

- [ ] Migration file naming ตาม convention
- [ ] Foreign keys มี constraint name ที่อ่านเข้าใจ
- [ ] Indexes บน foreign keys + columns ที่ใช้ filter/order
- [ ] `created_at`, `updated_at` ถ้าตามที่ project ใช้
- [ ] Backwards compatible — deploy ใหม่ไม่ break code เก่า
- [ ] Tested locally — apply + rollback (ถ้า framework support)
- [ ] Entity/model code update ให้ sync

## Common mistakes

1. **ลืม index** บน foreign key — query ช้าใน production
2. **NOT NULL บน column ใหม่ ไม่มี DEFAULT** — migration fail บน table ที่มี data
3. **Drop column ทั้งที่ยังมี code reference** — runtime error
4. **Naming convention** — table แบบ singular vs plural ต้อง consistent
5. **Cascade delete** ที่ไม่ตั้งใจ — clarify with user ถ้าไม่ชัด
