---
name: frontend-component
description: Create a new React component with proper structure, types, and tests. Use when user asks to "create", "add", or "build" a UI component, page, or view.
---

# Frontend Component

ใช้ skill นี้เมื่อต้องสร้าง React component ใหม่

## When to use

Activate when user asks for:
- "Create a new component for X"
- "Add a [Button/Modal/Form/etc.] component"
- "Build the X page"
- "I need a UI for Y"

Do NOT activate for:
- Modifying existing component (use Read + Edit directly)
- Pure logic (use a hook or util instead)
- Backend work

## Required input

Before starting, confirm:

1. **Component name** — PascalCase
2. **Type** — presentational (display only) or container (data fetching)
3. **Props** — what does it accept?
4. **Where it's used** — page, modal, sidebar, etc.
5. **Data needs** — local state, server state (TanStack Query), URL state, none

ถ้าไม่ชัด ถาม — อย่าเดา

## Process

### 1. Decide structure

```
src/components/{ComponentName}/
├── {ComponentName}.tsx
├── {ComponentName}.test.tsx
└── index.ts
```

หรือถ้าเป็น page:

```
src/pages/{PageName}/
├── {PageName}.tsx
├── {PageName}.test.tsx
├── components/   (page-specific subcomponents)
└── index.ts
```

### 2. Define Props

```typescript
type {ComponentName}Props = {
  // explicit types — no `any`
  // mark optional with ?
  // use union types for variants
};
```

- Default values via destructuring: `({ size = 'md' })`
- ถ้า component อาจรับ ref → use `forwardRef`

### 3. Implement component

**ทำ**:
- Functional component พร้อม hooks
- Tailwind classes — composition ไม่ใช่ `@apply`
- ใช้ shadcn/ui primitives ถ้ามี (Button, Input, Card, ...)
- Loading + error states ถ้ามี data fetching
- Accessible: aria labels, keyboard navigation, focus management

**อย่าทำ**:
- Class components
- Inline `style` (ใช้ Tailwind)
- Fetch ใน component (ใช้ hook + TanStack Query)
- `useState` สำหรับ server state

### 4. Server state (ถ้าจำเป็น)

ถ้า component ต้อง fetch data:

```typescript
const { data, isLoading, error } = useQuery({
  queryKey: ['{resource}', id],
  queryFn: () => fetch{Resource}(id),
});

if (isLoading) return <Skeleton />;
if (error) return <ErrorState error={error} />;
```

Hook อยู่ใน `src/hooks/use{Resource}.ts` — แยกจาก component

### 5. Tests

`{ComponentName}.test.tsx` ต้องมีอย่างน้อย:

- `it('renders without crashing')` — basic smoke
- `it('displays {key prop}')` — render correctness
- `it('calls onX when clicked')` — interaction (ถ้ามี)
- `it('shows loading state')` — ถ้ามี async

ใช้ `@testing-library/react` + Vitest

### 6. Export

`index.ts`:
```typescript
export { {ComponentName} } from './{ComponentName}';
export type { {ComponentName}Props } from './{ComponentName}';
```

ถ้า project มี barrel export ที่ `src/components/index.ts` — เพิ่มเข้าไป

### 7. Storybook (ถ้า project ใช้)

`{ComponentName}.stories.tsx` กับ stories:
- Default
- Loading (ถ้ามี)
- Error (ถ้ามี)
- Variants (size, color, etc.)

## Output checklist

- [ ] Component renders ใน dev server (`npm run dev`)
- [ ] TypeScript ไม่มี error (`tsc --noEmit`)
- [ ] Tests pass (`npm test`)
- [ ] No ESLint warnings
- [ ] Accessible: keyboard navigable, aria labels
- [ ] Responsive (test mobile breakpoint)

## Conventions

อ่าน `frontend/CLAUDE.md` ก่อน — project อาจมี convention เฉพาะ

Default:
- File: PascalCase
- Function: PascalCase
- Hook: `use` prefix, camelCase
- Type: PascalCase, ใช้ `type` ไม่ใช่ `interface` (ยกเว้นต้อง extend)
- ไม่ default export (ยกเว้น page component routing)
