# Claude Code Project Template

> Starter `.claude/` folder จาก Claude Code Mastery Workshop  
> นำไปใช้กับ project ใหม่ของคุณได้ทันที

---

## วิธีใช้ template นี้

### 1. Copy ไปยัง project ของคุณ

```bash
# จาก root ของ project ใหม่
cp -r path/to/claude-template/.claude .
cp path/to/claude-template/CLAUDE.md.example CLAUDE.md
```

### 2. แก้ CLAUDE.md ให้ตรง project ตัวเอง

เปิด `CLAUDE.md` แล้วแทน placeholder ที่ขีดเส้นใต้:
- `__PROJECT_NAME__` → ชื่อ project
- `__STACK__` → tech stack
- `__CONVENTIONS__` → convention หลัก 3 ข้อ

### 3. แก้ `.claude/settings.json`

- Update permissions ให้เหมาะกับ tools ที่ใช้จริง
- ตั้ง default model
- เพิ่ม env vars ถ้าต้องการ

### 4. ทดสอบว่า template ทำงาน

```bash
claude
```

แล้วถาม:
```
Read CLAUDE.md and tell me what you understand about this project.
```

ถ้า Claude ตอบได้ตรงและละเอียด → template setup สำเร็จ

---

## โครงสร้างของ template นี้

```
.claude/
├── settings.json              # project-level settings
├── settings.local.json.example # personal overrides (gitignore'd)
├── skills/
│   ├── api-endpoint/          # generic backend endpoint skill
│   ├── frontend-component/    # generic UI component skill
│   └── migration/             # database migration skill
├── agents/
│   ├── test-writer.md         # writes tests for implementation
│   ├── code-reviewer.md       # reviews changes before commit
│   └── doc-writer.md          # generates/updates documentation
├── hooks/
│   ├── pre-tool-use.sh        # safety check (block dangerous commands)
│   └── before-commit.sh       # quality gate (lint + test)
└── commands/
    ├── review.md              # /review — review uncommitted changes
    ├── plan.md                # /plan — start a planning session
    └── ship.md                # /ship — guide through commit + PR flow
```

---

## ปรับ template ให้เหมาะกับ project

### Project แบบ Java/Spring Boot
- ใช้ skills/api-endpoint ตามเดิม
- ลบ skills/frontend-component
- เพิ่ม `mvn` ใน settings.json permissions
- ใน hooks/before-commit.sh เปิด section maven, ลบ section node

### Project แบบ React/Frontend-only
- ลบ skills/api-endpoint
- ใช้ skills/frontend-component
- เพิ่ม `npm` ใน permissions
- ปรับ before-commit.sh ให้รัน vitest

### Project แบบ Python
- เปลี่ยน skills/api-endpoint ให้ใช้ FastAPI/Django patterns
- เพิ่ม `pip`, `pytest`, `ruff` ใน permissions
- before-commit.sh: ruff + pytest

### Monorepo (เหมือน workshop)
- ใช้ทั้งหมดได้
- เพิ่ม `backend/CLAUDE.md` และ `frontend/CLAUDE.md` แยก stack-specific rules

---

## MCP servers แนะนำ

หลังตั้ง template แล้ว เพิ่ม MCP ที่เกี่ยวกับ stack:

```bash
# Database (เลือกตาม DB ที่ใช้)
claude mcp add postgres -- npx -y @modelcontextprotocol/server-postgres "$DATABASE_URL"
# หรือ
claude mcp add sqlite -- npx -y @modelcontextprotocol/server-sqlite "/path/to/db.sqlite"

# GitHub (สำหรับ workflow)
claude mcp add github -e GITHUB_PERSONAL_ACCESS_TOKEN=$GITHUB_TOKEN -- npx -y @modelcontextprotocol/server-github

# Browser (สำหรับ E2E + scrape)
claude mcp add playwright -- npx -y @playwright/mcp@latest

# Filesystem (จำกัด scope สำหรับ safe file ops)
claude mcp add filesystem -- npx -y @modelcontextprotocol/server-filesystem /path/to/safe/dir
```

---

## Best practices ที่ template นี้ encode ไว้

1. **CLAUDE.md หลายระดับ** — root + per-stack ลด token waste
2. **Default model = Sonnet** — Opus เฉพาะตอน plan, Haiku สำหรับ mechanical
3. **Hooks block dangerous ops** — safety net แม้พลาด
4. **Skills > prompt copy-paste** — generate แบบ consistent
5. **Subagents สำหรับงาน parallel/specialized** — ไม่ทำให้ main context บวม

---

## Update template ของตัวเอง

หลังใช้ template ไปสักพัก คุณจะค้นพบว่า project ของคุณมี pattern เฉพาะ:

- skill ใหม่ที่ใช้บ่อย
- agent ที่ specialize เฉพาะ domain
- hook ที่ enforce กฎเฉพาะของทีม

แก้ template, commit เป็น repo ส่วนตัว แล้วใช้กับ project ใหม่ — โครงสร้างนี้ถูกออกแบบให้ extend ได้ง่าย

---

## หลังใช้ template ไป 1-2 สัปดาห์

ถามตัวเอง:

1. CLAUDE.md ของฉันโตจนเกินไปหรือยัง? ลบอะไรได้บ้าง?
2. มี skill ที่ถูก trigger บ่อยมากไหม → adjust description ให้ชัดขึ้น
3. มี skill ที่ไม่เคยถูก trigger เลย → ลบทิ้งหรือแก้ "When to use"
4. Hooks มีปัญหาอะไร — slow, false positive, ไม่ block ของจริง

ปรับ → commit → reuse
